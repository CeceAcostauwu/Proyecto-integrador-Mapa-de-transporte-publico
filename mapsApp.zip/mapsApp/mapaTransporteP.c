#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "Grafo.h"
#include "leerColectivos.h"
#include "agregarChoferes.h"
#include "corteControl.h"


void mostrarCorteControl();
void consultarRecorrido();
void mostrarGrafoBarrios();
void inicializarVectores(int dist[], int prev[], int tam);
void banner();

void rutaColes();
void limpiarBuffer();
void limpiarPantalla();
void pausar();

void mostrarMenu();


int main() {
    mostrarMenu();
    return 0;
}

void mostrarMenu() {
    int opcion;
    
    do {
        limpiarPantalla();
        printf("================================================\n");
        printf("    SISTEMA DE TRANSPORTE PUBLICO - CORRIENTES\n");
        printf("================================================\n\n");
        printf("  1. Carga de Barrios y Conexiones\n");
        printf("  2. Consultar Recorrido Entre Barrios\n");
        printf("  3. Ver Lista de Choferes\n");
        printf("  4. Salir\n\n");
        printf("================================================\n");
        printf("  Ingrese una opcion: ");
        
        if (scanf("%d", &opcion) != 1) {
            limpiarBuffer();
            opcion = -1;
        }
        limpiarBuffer();
        
        printf("\n");
        
        switch(opcion) {
            case 1:
                limpiarPantalla();
                printf("================================================\n");
                printf("    CARGA DE BARRIOS Y CONEXIONES\n");
                printf("================================================\n\n");
                mostrarCorteControl();
                pausar();
                break;
                
            case 2:
                limpiarPantalla();
                printf("================================================\n");
                printf("    CONSULTAR RECORRIDO ENTRE BARRIOS\n");
                printf("================================================\n\n");
                consultarRecorrido();
                pausar();
                break;
                
            case 3:
                limpiarPantalla();
                printf("================================================\n");
                printf("    LISTA DE COLECTIVOS\n");
                printf("================================================\n\n");
                mostrarGrafoBarrios();
                pausar();
                break;
                
            case 4:
                limpiarPantalla();
                printf("================================================\n");
                printf("Gracias por usar el sistema de transporte.\n");
                printf("Hasta pronto!\n");
                printf("================================================\n\n");
                break;
                
            default:
                printf("⚠ Opción invalida. Por favor, ingrese un número entre 1 y 4.\n");
                pausar();
                break;
        }
        
    } while(opcion != 4);
}

//1
void mostrarCorteControl() {
    int opcion = 0;
    
   	printf("1. Cargar Choferes\n");
    printf("2. Lista Choferes por Colectivo\n");
    
    if (scanf("%d", &opcion) != 1) {
            limpiarBuffer();
            opcion = -1;
    }
    
    switch (opcion){
    	case 1:
    			limpiarPantalla();
                printf("================================================\n");
                printf("    CARGA DE BARRIOS Y CONEXIONES\n");
                printf("================================================\n\n");
                agregarChoferes();
                pausar();
                break;
                
        case 2:
        		limpiarPantalla();
                printf("================================================\n");
                printf("    CARGA DE BARRIOS Y CONEXIONES\n");
                printf("================================================\n\n");	
        		listaPorColectivo();
        		pausar();
        		break;
        		
        default:
                printf("Opcion invalida. Por favor, ingrese un numero entre 1 y .\n");
                pausar();
                break;
	}

}


//===========================================================
//2
void consultarRecorrido() {
    tGrafoPonderado grafoBarrios;
    
    int dist[MAX_BARRIOS+1];
    int prev[MAX_BARRIOS+1];
    
    int origen, destino;
    bool error = false;
    
    inicializarGrafo(&grafoBarrios);
    cargarMapaTransporte(&grafoBarrios);
    
    // Inicializar vectores ANTES de usarlos
    inicializarVectores(dist, prev, MAX_BARRIOS);
    
    printf("\n Lista de Barrios:\n 1-Margen\n 2-Luna de Ketchup\n 3-Asfalto\n 4-Separacion\n 5-Laguna Mojada\n 6-Brahma\n 7-El Cholo\n 8-San Catalino\n");
    
    printf("\nIngrese barrio de ORIGEN (1 a %d): ", MAX_BARRIOS);
    fflush(stdin);
    scanf("%d", &origen);
    printf("Ingrese barrio de DESTINO (1 a %d): ", MAX_BARRIOS);
    fflush(stdin);
    scanf("%d", &destino);
    
    if(origen < 1 || origen > MAX_BARRIOS || destino < 1 || destino > MAX_BARRIOS) {
        printf("\nERROR: Los valores deben estar entre 1 y %d\n", MAX_BARRIOS);
        return;
    }
    
    // Calcular distancias con Dijkstra
    dijkstra(&grafoBarrios, origen, dist, prev);
    
    if(dist[destino] == INF) {
        printf("\nNo existe ruta posible entre los barrios.\n");
        return;
    }
    
    printf("\nDistancia minima desde %s a %s: %d\n", 
           vecNombreBarrios[origen-1], 
           vecNombreBarrios[destino-1], 
           dist[destino]);
    
    mostrarRuta(origen, destino, prev);
    
    int camino[20];
    int tope = 0;
    int actual = destino;

    while(actual != -1) {
        camino[tope++] = actual;
        if(actual == origen) break;
        actual = prev[actual];
    }

    /* Invertir el vector para dejarlo origen=destino */
    int i;
    for(i = 0; i < tope/2; i++) {
        int temp = camino[i];
        camino[i] = camino[tope-1-i];
        camino[tope-1-i] = temp;
    }

	
    mostrarColectivosDeRuta(&grafoBarrios, camino, tope);
}


//inicializaVector
void inicializarVectores(int dist[], int prev[], int tam) {
	int i;
    for(i = 0; i <= tam; i++) {
        dist[i] = INF;  // Distancia infinita inicialmente
        prev[i] = -1;   // Sin predecesor
    }
}

//=====================================================
//opcion 3; lista de choferes del colectivo
void mostrarGrafoBarrios() {
    
    listaColectivos();
}

//funciones utilidades
void banner(){
	printf("===============================================================\n");
printf(" _____                                      _                 \n");
printf("|_   _| __ __ _ _ __  ___ _ __   ___  _ __| |_ ___           \n");
printf("  | || '__/ _` | '_ \\/ __| '_ \\ / _ \\| '__| __/ _ \\          \n");
printf("  | || | | (_| | | | \\__ \\ |_) | (_) | |  | ||  __/          \n");
printf("  |_||_|  \\__,_|_| |_|___/ .__/ \\___/|_|   \\__\\___|          \n");
printf("                         |_|                                  \n");
printf("        ____        _     _ _                                 \n");
printf("       |  _ \\ _   _| |__ | (_) ___ ___                       \n");
printf("       | |_) | | | | '_ \\| | |/ __/ _ \\                      \n");
printf("       |  __/| |_| | |_) | | | (_| (_) |                     \n");
printf("       |_|    \\__,_|_.__/|_|_|\\___\\___/                      \n");
printf("                                                               \n");
printf("===============================================================\n");
}

void limpiarBuffer() {
    int c;
    while ((c = getchar()) != '\n' && c != EOF);
}

void limpiarPantalla() {
    #ifdef _WIN32
        system("cls");
    #else
        system("clear");
    #endif
    banner();
}

void pausar() {
    printf("\nPresione Enter para continuar...");
    limpiarBuffer();
    getchar();
}
